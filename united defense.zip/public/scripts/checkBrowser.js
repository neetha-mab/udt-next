// if browser is IE, redirect

if (window.document.documentMode) {
    window.location.replace('/outdated-browser.html')
}